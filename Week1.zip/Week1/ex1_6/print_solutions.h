#include <complex.h>

void print_solutions(const _Complex double *solutions, int no_roots);

