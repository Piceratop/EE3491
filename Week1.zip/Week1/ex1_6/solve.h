#include <complex.h>

int solve_linear_equation(_Complex double *solution_array, const _Complex double *a, const _Complex double *b);
int solve_quadratic_equation(_Complex double *solution_array, const _Complex double *a, const _Complex double *b, const _Complex double *c);
